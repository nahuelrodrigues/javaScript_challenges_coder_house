//clase 6 - arrays
// 1. incorporar al menos un array en tu proyecto 
// 2. utilizar al menos un método o propiedades vistos en clase.

//desafio complementario : ordenar estructura de datos función sort()

//precio envio
precioEnvio = 100;

//clase Producto
class Producto {
  constructor(id, nombre, precio, categoria, estrellas) {
    this.id = id;
    this.nombre = nombre;
    this.precio = Number(precio);
    this.categoria = categoria;
    this.estrellas = estrellas;

  }
  //calcula el iva
  sumaIva() {
    this.precio = this.precio * 1.21;
  }
  //calcula envio
  sumaEnvio(){
    this.precio = this.precio + precioEnvio;
  }
}
//Declaramos un array de productos para almacenar objetos 
const productos = [];
let productosOrdenados = [];
//usamos el método push para agregar al array sin orden alguno
productos.push(new Producto(0,"arroz", "100", "legumbres", 5));
productos.push(new Producto(1,"lenteja", "150","legumbres", 3));
productos.push(new Producto(2,"granola", "350", "cereal", 4));
//Iteramos el array con for...of para sumarles impuestos de iva + envío
for (const producto of productos) producto.sumaIva();
for (const producto of productos) producto.sumaEnvio();
//ordenar productos por estrellas[en mi caso sería 5:muy vendido 1:poco vendido]
productosOrdenados = productos.sort(function (a, b) {
  // invierto a y b para mostrar de más vendido a menos vendido
  return b.estrellas - a.estrellas;
});
//muestro por consola los productos ordenados
console.log(productosOrdenados);



/* // esto lo uso para que no se me crashee la carga cuando pido datos por prompt
setTimeout(() => {
  saludar();
  infoUser();
}, 1000);
 */


//declarando variables
let menu = document.querySelector("#menu-bar");
let navbar = document.querySelector(".navbar");
let header = document.querySelector(".header-3");
let scrollTop = document.querySelector(".scroll-top");

//Si el usuario hace click en #menu-bar(icono de menu fa-bars )
menu.addEventListener("click", () => {
  // que cambie a fa-times (icono crucecita de salida)
  menu.classList.toggle("fa-times");
  //y despliegue el navbar
  navbar.classList.toggle("active");
});

//Si el usuario scrollea
window.onscroll = () => {
  //quita fa-times
  menu.classList.remove("fa-times");
  //quita el navbar desplegable
  navbar.classList.remove("active");

  //Si el usuario scrollea + de 250px en el eje Y
  if (window.scrollY > 250) {
    //agrega el header 3
    header.classList.add("active");
  } else {
    //quita el header 3
    header.classList.remove("active");
  }

  //Si el usuario scrollea + de 250px en el eje Y
  if (window.scrollY > 250) {
    //fija al inicio
    scrollTop.style.display = "initial";
  } else {
    //nada
    scrollTop.style.display = "none";
  }
};

// Swiperv6.6.2 - Most Modern Mobile Touch Slider
// MANUAL : https://swiperjs.com/get-started

//inicializando
var swiper = new Swiper(".home-slider", {
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
  //autoplay cada 3000ms
  autoplay: {
    delay: 3000,
    disableOnInteraction: false,
  },
  //loopeo
  loop: true,
});
